#!/bin/sh
echo "packing img3"
image3maker -t rdsk -f RestoreRamdisk.dmg -o ramdisk
echo "DONE"
