#!/bin/sh
echo "Start mounting"
hdiutil attach RestoreRamdisk.dmg -mountpoint mp
echo "DONE"
