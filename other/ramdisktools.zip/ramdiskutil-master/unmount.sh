#!/bin/sh
echo "Start unmounting"
hdiutil detach mp
echo "DONE"
