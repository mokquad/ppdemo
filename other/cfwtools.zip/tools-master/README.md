# Tools
Here are the tools for playing with iOS firmwares.

xpwntool: Firmware decryption utility

dmg: RootFS decryption utility

irecovery: Tools for sending iBSS and iBEC to device, and communicating with device in DFU mode

iBoot32Patcher: Patch iBoot (iBSS and iBEC) out of signature checks

sshtool: SSH connection utility

image3maker: Create img3 image for booting

reimagine: Almost the same as xpwntool, but with higher reliablity.
